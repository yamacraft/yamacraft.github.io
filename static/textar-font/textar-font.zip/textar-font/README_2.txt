Textar Font ver.0.2(Temporary）

http://font.textar.tv/ にて配布されていた、アスキーアート表示用のフォントファイルです。
元製作者様のソースコードでコンパイルしたフォントを同梱しているので、正式版と中身に違いはないはずです。
こちらに含まれているフォントファイルに関しては、元製作者様ではなく、twitter:@ariki2002または@yamacraftにご連絡ください。

textar-min.ttfは、JIS X 0208で定義されている第一水準漢字と第二水準漢字以外の漢字グリフを切り捨てたフォントです。
ウェブフォントとしての使用を想定しています。（README_JAより引用）

ライセンス:
  IPA Font License Agreement v1.0
