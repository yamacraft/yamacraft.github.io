Textar Font ver.0.2

Textarフォントは、IPA Pゴシックフォント ver.3.02を改変して作られた
日本語のプロポーショナルフォントです。
MS Pゴシックに合わせて文字幅や文字形を調整しているので、
アスキーアートを適切に表示することができます。

ライセンス:
  IPA Font License Agreement v1.0

フォントの作り方:
  1. FontForge をインストールしてください。

  2. 以下のコマンドを実行してください。
    $ cd src
    $ fontforge -script gen1.py
    $ fontforge -script gen2.pe

"textar-min.**"のファイルは何？:
  ファイルサイズを小さくするために、
  JIS X 0208で定義されている第一水準漢字と第二水準漢字以外の
  漢字グリフを切り捨てたフォントです。
  ウェブフォントとしての使用を想定しています。

woff形式のフォントについて:
  woff形式のフォントはsfnt2woffで変換しています
  (http://people.mozilla.org/~jkew/woff/)。

eot形式のフォントについて:
  eot形式のフォントはttf2eotで変換しています
  (http://code.google.com/p/ttf2eot/)。

svg形式のフォントについて:
  svg形式のフォントはbatikのttf2svgで変換しています
  (http://xmlgraphics.apache.org/batik/)。

"textar-patch.otf"について:
  スクリプトでは行いにくい細かい調整を施したグリフを収録しています。
  IPA Pゴシックフォント ver.3.02を改変して作ったフォントファイルですので、
  厳密にいえば、これにもIPA Font License Agreement v1.0が適用されます。

