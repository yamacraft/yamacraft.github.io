Textar Font ver.0.2

Textar Font is a japanese propotional font,
derived from the IPA PGothic font ver.3.02.
It aims to represent Shift_JIS art graphics properly,
almost all of which require the MS PGothic font.

LICENSE:
  IPA Font License Agreement v1.0

HOW TO GENERATE FONTS:
  1. Install FontForge.

  2. Run the following commands.
    $ cd src
    $ fontforge -script gen1.py
    $ fontforge -script gen2.pe

WHAT'S "textar-min.**"?
  It includes minimal Kanji glyphs to reduce the file size,
  specifically, the first level Kanji and the second level Kanji only
  (http://en.wikipedia.org/wiki/JIS_X_0208).

ABOUT WOFF:
  WOFF font was converted by sfnt2woff
  (http://people.mozilla.org/~jkew/woff/).

ABOUT EOT:
  EOT font was converted by ttf2eot
  (http://code.google.com/p/ttf2eot/).

ABOUT SVG:
  SVG font was converted by ttf2svg on batik
  (http://xmlgraphics.apache.org/batik/)
